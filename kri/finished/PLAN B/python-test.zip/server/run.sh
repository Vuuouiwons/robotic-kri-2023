conda activate server
python server.py