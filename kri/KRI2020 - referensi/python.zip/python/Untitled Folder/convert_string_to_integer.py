msg = '#123|123|123'

print(int(msg[1:4]))